<?php
session_start();

$servername = 'localhost';
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

if ($_SESSION['email'] !== 'admin@gmail.com') {
    header("Location: index.php");
    exit;
}

if(isset($_POST['add'])){
    $id = $_POST['id'];
    $merek = $_POST['merek'];
    $model = $_POST['model'];
    $tahun = $_POST['tahun'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    try {
        $stmt = $pdo->prepare("INSERT INTO mobil (id_mobil, merek, model, tahun, harga, stok) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$id, $merek, $model, $tahun, $harga, $stok]);
        $success = true;
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Car</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            position: relative;
            min-height: 100vh;
        }
        .header {
            background-color: #f8f9fa; /* Background abu-abu muda */
            color: #333; /* Warna teks */
            padding: 10px;
            text-align: center;
        }
        .container {
            width: 50%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form {
            text-align: center;
            margin-bottom: 20px;
        }
        .form input[type="text"] {
            padding: 10px;
            width: 100%;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form input[type="submit"] {
            padding: 10px 20px;
            background-color: #007bff;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        .form input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
            background-color: #f8f9fa; /* Background abu-abu muda */
            padding: 10px;
            text-align: center;
        }
        .btn-back {
            display: inline-block;
            padding: 10px 20px;
            background-color: #dc3545;
            border: none;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 20px;
            margin-right: 10px;
        }
        .btn-back:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Add Car</h1>
    </div>

    <div class="container">
        <h2>Tambah Mobil Baru</h2>

        <!-- Form to Add Car -->
        <form class="form" action="#" method="post">
            <input type="text" name="id" placeholder="ID Mobil" required>
            <input type="text" name="merek" placeholder="Merek" required>
            <input type="text" name="model" placeholder="Model" required>
            <input type="text" name="tahun" placeholder="Tahun" required>
            <input type="text" name="harga" placeholder="Harga" required>
            <input type="text" name="stok" placeholder="Stok" required>
            <input type="submit" name="add" value="Tambah Mobil">
        </form>

        <?php if(isset($success)): ?>
        <div style="color:green; text-align:center; margin-top: 20px;">Mobil berhasil ditambahkan.</div>
        <?php elseif(isset($error)): ?>
        <div style="color:red; text-align:center; margin-top: 20px;"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Button to go back to Dashboard and Mobil page -->
        <a href="dashboard_admin.php" class="btn-back">Kembali ke Dashboard</a>
        <a href="mobil.php" class="btn-back">Kembali ke Mobil</a>
    </div>
    
    <div class="footer">
        <p>&copy; <?php echo date("Y"); ?> Add Car</p>
    </div>
</body>
</html>
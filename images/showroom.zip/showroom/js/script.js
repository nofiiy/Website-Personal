// Function untuk menampilkan detail mobil di dalam pop-up
function showDetails(element) {
    // Ambil elemen pop-up
    var popup = document.getElementById('carDetailPopup');
    if (!popup) return;

    // Ambil elemen mobil yang dipilih
    var carItem = element.closest('.car-item');
    if (!carItem) return;

    // Ambil informasi mobil dari elemen
    var carTitle = carItem.querySelector('.car-title').innerText;
    var carPrice = carItem.querySelector('.harga').innerText;
    var carDescription = carItem.querySelector('.deskripsi').innerText;

    // Isi konten pop-up dengan detail mobil
    document.getElementById('carTitle').innerText = carTitle;
    document.getElementById('carPrice').innerText = carPrice;
    document.getElementById('carDescription').innerText = carDescription;

    // Tentukan posisi pop-up agar berada di sebelah elemen yang di-hover
    var rect = carItem.getBoundingClientRect();
    var popupWidth = popup.offsetWidth;
    var popupHeight = popup.offsetHeight;

    // Default posisi pop-up di sebelah kanan
    var topPosition = Math.max(window.scrollY + rect.top, 20); // Tidak melebihi batas atas viewport
    var leftPosition = window.scrollX + rect.right + 20;

    // Cek apakah pop-up keluar dari viewport (batas kanan)
    if (leftPosition + popupWidth > window.innerWidth) {
        // Jika keluar batas layar di kanan, tampilkan pop-up di kiri elemen
        leftPosition = Math.max(window.scrollX + rect.left - popupWidth - 20, 20);
    }

    // Cek apakah pop-up keluar dari viewport bawah
    if (topPosition + popupHeight > window.innerHeight + window.scrollY) {
        // Jika keluar batas bawah, geser pop-up agar terlihat di atas elemen
        topPosition = window.scrollY + rect.bottom - popupHeight - 20;
    }

    // Batasi agar tidak keluar dari viewport atas
    if (topPosition < window.scrollY) {
        topPosition = window.scrollY + 20;
    }

    // Atur posisi pop-up
    popup.style.top = topPosition + 'px';
    popup.style.left = leftPosition + 'px';

    // Tampilkan pop-up dengan animasi yang halus
    popup.style.display = 'block';
    popup.style.opacity = '1';
}

// Function untuk menyembunyikan detail pop-up
function hideDetails() {
    var popup = document.getElementById('carDetailPopup');
    if (popup) {
        popup.style.opacity = '0';
        setTimeout(function () {
            popup.style.display = 'none';
        }, 200); // Tunggu 200ms sebelum benar-benar menyembunyikan pop-up
    }
}

// Function untuk mencari mobil dengan AJAX berdasarkan budget
function searchByBudget() {
    var budget = document.getElementById('budget').value;

    // Panggil AJAX untuk melakukan pencarian berdasarkan budget
    $.ajax({
        url: 'dashboard_pembeli.php',  
        data: { budget: budget },  // Kirim budget pengguna ke server
        success: function(response) {
            $('#result-area').html(response);  // Tampilkan hasil pencarian
        }
    });
}

// Function untuk menampilkan progress bar kecocokan mobil dengan budget
function updateCompatibilityScore(element, score) {
    var compatibilityBar = element.querySelector('.compatibility-bar');
    
    // Tentukan warna dan ukuran progress bar berdasarkan score
    if (score < 50000000) {
        compatibilityBar.style.backgroundColor = 'green';
        compatibilityBar.style.width = '90%';  // Sangat cocok
    } else if (score < 100000000) {
        compatibilityBar.style.backgroundColor = 'yellow';
        compatibilityBar.style.width = '60%';  // Cukup cocok
    } else {
        compatibilityBar.style.backgroundColor = 'red';
        compatibilityBar.style.width = '30%';  // Kurang cocok
    }
}

// Function untuk inisialisasi halaman dengan fitur kecocokan
function initPage() {
    // Iterasi setiap item mobil dan update progress bar
    var carItems = document.querySelectorAll('.car-item');
    carItems.forEach(function(carItem) {
        var score = carItem.dataset.perceptronScore;  // Ambil perceptron score dari elemen
        updateCompatibilityScore(carItem, score);
    });

    // Event listener untuk filter budget menggunakan AJAX
    document.getElementById('budget').addEventListener('input', function() {
        searchByBudget();
    });
}

// Panggil initPage saat halaman sudah siap
document.addEventListener('DOMContentLoaded', initPage);
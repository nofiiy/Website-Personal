<?php
session_start();

$servername = 'localhost'; 
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$error = ''; // Inisialisasi variabel error

// Login process
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if admin exists
    $stmt = $pdo->prepare("SELECT * FROM pegawai WHERE email = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($admin) {
        // Verify password
        if ($password == 'admin') { // Kata sandi admin adalah 'admin'
            // Set session variables
            $_SESSION['email'] = $admin['email'];
            $_SESSION['id_pegawai'] = $admin['id_pegawai']; // Set id_pegawai session

            // Redirect to dashboard
            header("Location: dashboard_admin.php"); // Redirect to admin dashboard
            exit();
        } else {
            $error = "Email atau password salah!";
        }
    } else {
        // Check if user exists in pembeli table
        $stmt = $pdo->prepare("SELECT * FROM pembeli WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Verify password
            if (password_verify($password, $user['password'])) {
                // Set session variables
                $_SESSION['email'] = $user['email'];
                $_SESSION['id_pembeli'] = $user['id_pembeli']; // Set id_pembeli session

                // Redirect to buyer dashboard
                header("Location: dashboard_pembeli.php"); 
                exit();
            } else {
                $error = "Email atau password salah!";
            }
        } else {
            $error = "Email atau password salah!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>Login - Showroom JAYA ABADI</title>
</head>
<body>
    <div class="container">
        <h1>Welcome to showroom JAYA ABADI</h1>
        <?php if(isset($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="" method="post">
            <input type="email" name="email" placeholder="Email" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit" name="login">Login</button>
        </form>
        <p>Belum memiliki akun? <a href="register.php">Register</a></p>
    </div>
</body>
</html>
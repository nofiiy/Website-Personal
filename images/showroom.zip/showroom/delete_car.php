<?php
session_start();

$servername = 'localhost';
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        // Buat query untuk menghapus mobil berdasarkan ID
        $sql = "DELETE FROM mobil WHERE id_mobil = :id";

        // Persiapkan statement
        $stmt = $pdo->prepare($sql);

        // Bind parameter
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        // Eksekusi statement
        if ($stmt->execute()) {
            echo "Car successfully deleted.";
        } else {
            echo "Error deleting car.";
        }
    } else {
        echo "ID not specified.";
    }
} else {
    echo "Invalid request method.";
}
?>
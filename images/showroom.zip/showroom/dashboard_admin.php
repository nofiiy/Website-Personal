<?php
session_start();

$servername = 'localhost'; 
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

if ($_SESSION['email'] !== 'admin@gmail.com') {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            background-color: #ddd;
            padding: 20px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            flex-grow: 1;
        }
        h2 {
            text-align: center;
            font-size: 28px;
            margin-bottom: 30px;
            color: #333;
            position: relative;
        }
        h2:after {
            content: '';
            width: 60px;
            height: 3px;
            background-color: #007bff;
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
        }
        .welcome {
            text-align: center;
            margin-bottom: 30px;
        }
        .welcome p {
            margin: 10px 0;
            font-size: 18px;
        }
        .welcome .subtitle {
            font-size: 20px;
            font-weight: bold;
            color: #007bff;
        }
        .chart-container {
            margin: 40px auto;
            text-align: center;
        }
        .link-group {
            display: flex;
            justify-content: space-around;
            margin-top: 40px;
            flex-wrap: wrap;
        }
        .link-group a {
            text-decoration: none;
            color: #ffffff;
            background-color: #007bff;
            padding: 15px 25px;
            border-radius: 30px;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.3s;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.4);
            margin: 10px;
        }
        .link-group a:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 86, 179, 0.5);
        }
        .footer {
            background-color: #ddd;
            padding: 20px;
            text-align: center;
            font-size: 16px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="header">
        Dashboard Admin
    </div>

    <div class="container">
        <div class="welcome">
            <p>Selamat Datang, <span class="subtitle"><?php echo $_SESSION['email']; ?></span>!</p>
            <p>Sebagai Admin Showroom.</p>
        </div>

        <!-- Chart -->
        <div class="chart-container">
            <canvas id="myChart" width="200" height="75"></canvas>
        </div>

        <!-- Link Group -->
        <div class="link-group">
            <a href="mobil.php">Lihat semua mobil</a>
            <a href="detail_penjualan.php">Lihat detail penjualan</a>
            <a href="index.php">Log Out</a>
        </div>
    </div>
    
    <div class="footer">
        &copy; <?php echo date("Y"); ?> Admin Dashboard
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Load Chart.js -->
    <script>
        // Function to draw the chart
        <?php
        // Query to get total sales for each car
        $stmt = $pdo->query("SELECT id_mobil, COUNT(*) AS total_sales FROM penjualan GROUP BY id_mobil");
        $sales_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ?>

        // Prepare data for Chart.js
        const labels = [];
        const data = [];

        <?php foreach ($sales_data as $sale): ?>
            labels.push('<?php echo $sale['id_mobil']; ?>');
            data.push(<?php echo $sale['total_sales']; ?>);
        <?php endforeach; ?>

        // Draw the chart
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Total Sales',
                    data: data,
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        enabled: true,
                        backgroundColor: '#007bff',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        suggestedMin: 0,
                        suggestedMax: 50
                    }
                }
            }
        });
    </script>
</body>
</html>
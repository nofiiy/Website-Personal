<?php
session_start();

$servername = 'localhost'; 
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

if ($_SESSION['email'] !== 'admin@gmail.com') {
    header("Location: index.php");
    exit;
}

// Function to fetch cars with optional search
function fetchCars($pdo, $offset, $limit, $search = '') {
    if ($search) {
        // Query with search filter for merek or model
        $stmt = $pdo->prepare("SELECT * FROM mobil WHERE merek LIKE :search OR model LIKE :search LIMIT :offset, :limit");
        $searchParam = "%$search%";
        $stmt->bindParam(':search', $searchParam, PDO::PARAM_STR);
    } else {
        // Default query without search
        $stmt = $pdo->prepare("SELECT * FROM mobil LIMIT :offset, :limit");
    }
    
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to count cars with optional search
function countCars($pdo, $search = '') {
    if ($search) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM mobil WHERE merek LIKE :search OR model LIKE :search");
        $searchParam = "%$search%";
        $stmt->bindParam(':search', $searchParam, PDO::PARAM_STR);
    } else {
        $stmt = $pdo->query("SELECT COUNT(*) FROM mobil");
    }
    
    $stmt->execute();
    return $stmt->fetchColumn();
}

// Pagination and search logic
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$search = isset($_GET['search']) ? $_GET['search'] : '';
$limit = 5;
$offset = ($page - 1) * $limit;

$totalCars = countCars($pdo, $search);
$totalPages = ceil($totalCars / $limit);

$cars = fetchCars($pdo, $offset, $limit, $search);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Mobil</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Roboto', sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; min-height: 100vh; display: flex; flex-direction: column; }
        .header { background-color: #ddd; padding: 20px; text-align: center; font-size: 24px; font-weight: bold; color: #333; }
        .container { width: 90%; max-width: 1200px; margin: 20px auto; background-color: #ffffff; padding: 30px; border-radius: 10px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); flex-grow: 1; }
        h2 { text-align: center; font-size: 28px; margin-bottom: 30px; color: #333; position: relative; }
        h2:after { content: ''; width: 60px; height: 3px; background-color: #007bff; position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%); }
        .add-car-btn, .back-to-dashboard-btn { text-align: center; margin-bottom: 20px; }
        .add-car-btn button, .back-to-dashboard-btn button { color: #ffffff; background-color: #007bff; padding: 15px 25px; border-radius: 30px; font-weight: bold; transition: background-color 0.3s, transform 0.3s; box-shadow: 0 4px 15px rgba(0, 123, 255, 0.4); cursor: pointer; }
        .add-car-btn button:hover, .back-to-dashboard-btn button:hover { background-color: #0056b3; transform: translateY(-2px); box-shadow: 0 6px 20px rgba(0, 86, 179, 0.5); }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 16px; color: #555; }
        th, td { padding: 15px; text-align: center; border-bottom: 1px solid #ddd; }
        th { background-color: #f2f2f2; font-weight: bold; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        tr:hover { background-color: #f1f1f1; }
        .delete-btn, .update-btn { padding: 8px 15px; border: none; color: #ffffff; background-color: #007bff; border-radius: 5px; cursor: pointer; transition: background-color 0.3s; }
        .delete-btn:hover, .update-btn:hover { background-color: #0056b3; }
        .pagination { text-align: center; margin-top: 30px; margin-bottom: 20px; }
        .pagination a { display: inline-block; padding: 6px 10px; margin-right: 4px; border: 1px solid #ccc; background-color: #f8f9fa; color: #333; text-decoration: none; }
        .pagination a.active { background-color: #007bff; color: #fff; }
        .pagination a:hover { background-color: #ccc; }
        .footer { background-color: #ddd; padding: 20px; text-align: center; position: relative; width: 100%; font-size: 16px; color: #333; margin-top: 20px; }
        .search-form { margin-bottom: 20px; text-align: center; }
        .search-input { padding: 10px; font-size: 16px; width: 300px; border: 1px solid #ccc; border-radius: 5px; }
        .search-btn { padding: 10px 20px; background-color: #007bff; color: #fff; border: none; border-radius: 5px; cursor: pointer; }
        .search-btn:hover { background-color: #0056b3; }
    </style>
</head>
<body>
    <div class="header">Admin Dashboard - Mobil</div>

    <div class="container">
        <h2>Semua Mobil</h2>

        <!-- Search Form -->
        <div class="search-form">
            <form method="GET" action="">
                <input type="text" name="search" class="search-input" placeholder="Cari berdasarkan Merek atau Model" value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="search-btn">Cari</button>
            </form>
        </div>

        <!-- Add Car Button -->
        <div class="add-car-btn">
            <button onclick="window.location.href='add_car.php';">Tambah Mobil</button>
        </div>

        <!-- Table of cars -->
        <table>
            <tr>
                <th>ID</th>
                <th>Merek</th>
                <th>Model</th>
                <th>Tahun</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Action</th>
            </tr>
            <?php if (count($cars) > 0): ?>
                <?php foreach ($cars as $car): ?>
                    <tr>
                        <td><?php echo $car['id_mobil']; ?></td>
                        <td><?php echo $car['merek']; ?></td>
                        <td><?php echo $car['model']; ?></td>
                        <td><?php echo $car['tahun']; ?></td>
                        <td><?php echo number_format($car['harga'], 0, ',', '.'); ?></td>
                        <td><?php echo $car['stok']; ?></td>
                        <td>
                            <a class="update-btn" href="edit.php?id=<?php echo $car['id_mobil']; ?>">Edit</a>
                            <a class="delete-btn" href="?action=delete&id=<?php echo $car['id_mobil']; ?>">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7">Tidak ada mobil yang ditemukan.</td>
                </tr>
            <?php endif; ?>
        </table>

        <!-- Pagination -->
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo htmlspecialchars($search); ?>" class="<?php if ($i == $page) echo 'active'; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
        </div>

        <!-- Back to Dashboard Button -->
        <div class="back-to-dashboard-btn">
            <button onclick="window.location.href='dashboard_admin.php';">Kembali ke Dashboard</button>
        </div>
    </div>

    <div class="footer">
        &copy; <?php echo date("Y"); ?> Admin Dashboard
    </div>
</body>
</html>

<?php
session_start();

$servername = 'localhost';
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

if ($_SESSION['email'] !== 'admin@gmail.com') {
    header("Location: index.php");
    exit;
}

// Function to fetch car details by ID
function fetchCarDetails($pdo, $id) {
    $stmt = $pdo->prepare("SELECT * FROM mobil WHERE id_mobil = ?");
    $stmt->execute([$id]);
    $car = $stmt->fetch(PDO::FETCH_ASSOC);
    return $car;
}

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    header("Location: dashboard_admin.php");
    exit;
}

$id = $_GET['id'];

// Fetch car details by ID
$car = fetchCarDetails($pdo, $id);

if (!$car) {
    echo "Car not found.";
    exit;
}

// Handle form submission
$update_success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $merek = $_POST['merek'];
    $model = $_POST['model'];
    $tahun = $_POST['tahun'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $sql = "UPDATE mobil SET merek = ?, model = ?, tahun = ?, harga = ?, stok = ? WHERE id_mobil = ?";
    $stmt = $pdo->prepare($sql);
    $update_success = $stmt->execute([$merek, $model, $tahun, $harga, $stok, $id]);

    if ($update_success) {
        echo "<script>alert('Car updated successfully!'); window.location.href='mobil.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Car</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            position: relative;
            min-height: 100vh;
        }
        .header {
            background-color: #ddd;
            padding: 10px;
            text-align: center;
        }
        .container {
            width: 50%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            margin-top: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            padding: 8px 15px;
            background-color: #007bff;
            border: none;
            color: #fff;
            border-radius: 3px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .back-btn {
            text-align: center;
            margin-top: 20px;
        }
        .back-btn button {
            padding: 8px 15px;
            border: 1px solid #007bff;
            background-color: #007bff;
            color: white;
            border-radius: 3px;
            cursor: pointer;
        }
        .back-btn button:hover {
            background-color: #0056b3;
        }
        .alert {
            padding: 15px;
            margin-top: 20px;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Edit Car</h1>
    </div>

    <div class="container">
        <form method="POST">
            <label for="merek">Merek:</label>
            <input type="text" id="merek" name="merek" value="<?php echo $car['merek']; ?>" required>

            <label for="model">Model:</label>
            <input type="text" id="model" name="model" value="<?php echo $car['model']; ?>" required>

            <label for="tahun">Tahun:</label>
            <input type="text" id="tahun" name="tahun" value="<?php echo $car['tahun']; ?>" required>

            <label for="harga">Harga:</label>
            <input type="text" id="harga" name="harga" value="<?php echo $car['harga']; ?>" required>

            <label for="stok">Stok:</label>
            <input type="text" id="stok" name="stok" value="<?php echo $car['stok']; ?>" required>

            <input type="submit" value="Update">
        </form>

        <div class="back-btn">
            <button onclick="window.location.href='mobil.php';">Kembali</button>
        </div>
    </div>
</body>
</html>
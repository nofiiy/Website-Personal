<?php
session_start();

$servername = 'localhost'; 
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$error = ''; // Inisialisasi variabel error

// Registration process
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    // Generate id_pembeli secara random
    $id_pembeli = mt_rand(100000, 999999);

    // Simple validation
    if (empty($email) || empty($password) || empty($nama) || empty($alamat) || empty($telepon)) {
        $error = "Semua kolom harus diisi!";
    } elseif (strlen($password) < 5 || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $error = "Password harus memiliki minimal 5 karakter dengan setidaknya satu huruf besar dan satu angka!";
    } elseif (!preg_match('/^[0-9]{10,12}$/', $telepon)) {
        $error = "Format telepon tidak valid!";
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT * FROM pembeli WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $error = "Email sudah terdaftar!";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Add new user
            $stmt = $pdo->prepare("INSERT INTO pembeli (id_pembeli, email, password, nama, alamat, telepon) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$id_pembeli, $email, $hashed_password, $nama, $alamat, $telepon]);
            $_SESSION['email'] = $email;
            header("Location: index.php"); // Redirect to login page after successful registration
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('assets/showroom.jpg'); /* Pastikan path menuju gambar benar */
            background-size: cover; /* Menutupi seluruh halaman */
            background-position: center; /* Memusatkan gambar */
            background-repeat: no-repeat; /* Mencegah pengulangan gambar */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 300px;
            padding: 20px;
            background-color: rgba(200, 200, 200, 0.8); /* Background abu-abu muda dengan opasitas 0.8 */
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }
        h1 {
            text-align: center;
            margin-top: 0;
            color: #333;
            font-size: 24px; /* Ukuran font */
            margin-bottom: 20px; /* Jarak ke bawah */
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); /* Efek bayangan teks */
        }
        form {
            margin-top: 20px;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="tel"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #007bff;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            margin-bottom: 10px;
            text-align: center;
        }
        p {
            text-align: center;
            margin-top: 10px;
            color: #333;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to showroom JAYA ABADI</h1>
        <?php if($error !== ''): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="" method="post">
            <input type="text" name="nama" placeholder="Nama" required><br>
            <input type="text" name="alamat" placeholder="Alamat" required><br>
            <input type="tel" name="telepon" pattern="[0-9]{10,12}" placeholder="Telepon" required><br>
            <input type="email" name="email" placeholder="Email" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit" name="register">Register</button>
        </form>
        <p>Sudah memiliki akun? <a href="index.php">Login</a></p>
    </div>
</body>
</html>
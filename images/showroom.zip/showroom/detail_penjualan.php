<?php
session_start();

$servername = 'localhost'; 
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

if ($_SESSION['email'] !== 'admin@gmail.com') {
    header("Location: index.php");
    exit;
}

// Fetch data penjualan dan urutkan berdasarkan tanggal_penjualan terbaru
$stmt = $pdo->query("SELECT * FROM penjualan ORDER BY tanggal_penjualan DESC");
$penjualan = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Jika tidak ada data penjualan
if (!$penjualan) {
    $no_data = true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Penjualan</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            font-size: 28px;
            margin-bottom: 30px;
            color: #333;
            position: relative;
        }
        h2:after {
            content: '';
            width: 60px;
            height: 3px;
            background-color: #007bff;
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            font-size: 16px;
            color: #555;
        }
        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .back-button {
            text-align: center;
            margin-top: 20px;
        }
        .back-button a {
            text-decoration: none;
            background-color: #007bff;
            color: #ffffff;
            padding: 15px 30px;
            border-radius: 50px;
            font-weight: 700;
            transition: background-color 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.4);
        }
        .back-button a:hover {
            background-color: #0056b3;
            box-shadow: 0 6px 20px rgba(0, 86, 179, 0.5);
        }
        .no-data {
            text-align: center;
            font-size: 18px;
            color: #999;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Detail Penjualan</h2>

        <?php if (isset($no_data) && $no_data): ?>
            <p class="no-data">Tidak ada data penjualan ditemukan.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Penjualan</th>
                        <th>ID Mobil</th>
                        <th>ID Pembeli</th>
                        <th>ID Pegawai</th>
                        <th>Tanggal Penjualan</th>
                        <th>Jumlah</th>
                        <th>Total Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($penjualan as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id_penjualan']); ?></td>
                        <td><?php echo htmlspecialchars($row['id_mobil']); ?></td>
                        <td><?php echo htmlspecialchars($row['id_pembeli']); ?></td>
                        <td><?php echo htmlspecialchars($row['id_pegawai']); ?></td>
                        <td><?php echo htmlspecialchars($row['tanggal_penjualan']); ?></td>
                        <td><?php echo htmlspecialchars($row['jumlah']); ?></td>
                        <td>Rp <?php echo number_format($row['total_harga'], 0, ',', '.'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="back-button">
            <a href="dashboard_admin.php">Kembali</a>
        </div>
    </div>
</body>
</html>

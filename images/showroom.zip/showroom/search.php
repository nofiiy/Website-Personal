<?php
session_start();

$servername = 'localhost';
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Function to search cars
function searchCars($pdo, $search) {
    $stmt = $pdo->prepare("SELECT * FROM mobil WHERE merek LIKE :search OR model LIKE :search");
    $stmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
    $stmt->execute();
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $cars;
}

// Handle AJAX request
if (isset($_GET['q'])) {
    $search = $_GET['q'];
    $cars = searchCars($pdo, $search);
    echo json_encode($cars);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Cars</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Search Cars</h1>
    <input type="text" id="search" placeholder="Enter car brand or model">
    <button id="searchButton">Search</button>
    <div id="results"></div>

    <script>
        $(document).ready(function() {
            $('#searchButton').on('click', function() {
                var query = $('#search').val();
                $.ajax({
                    url: 'search.php', // Ganti dengan nama file PHP Anda jika berbeda
                    type: 'GET',
                    data: { q: query },
                    success: function(data) {
                        var cars = JSON.parse(data);
                        var html = '<ul>';
                        cars.forEach(function(car) {
                            html += '<li>' + car.merek + ' ' + car.model + '</li>';
                        });
                        html += '</ul>';
                        $('#results').html(html);
                    },
                    error: function() {
                        $('#results').html('<p>An error has occurred</p>');
                    }
                });
            });
        });
    </script>
</body>
</html>

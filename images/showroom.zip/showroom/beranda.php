<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$host = '127.0.0.1'; // Host IP address
$port = '3307';      // Port
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Fetch mobil data
$stmt = $pdo->query("SELECT * FROM mobil");
$mobil = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pegawai</title>
</head>
<body>
    <h1>Dashboard Pegawai (Admin)</h1>
    <h2>Data Mobil</h2>
    <table border="1">
        <tr>
            <th>ID Mobil</th>
            <th>Merek</th>
            <th>Model</th>
            <th>Tahun</th>
            <th>Harga</th>
            <th>Stok</th>
        </tr>
        <?php foreach ($mobil as $row): ?>
            <tr>
                <td><?php echo $row['id_mobil']; ?></td>
                <td><?php echo $row['merek']; ?></td>
                <td><?php echo $row['model']; ?></td>
                <td><?php echo $row['tahun']; ?></td>
                <td><?php echo $row['harga']; ?></td>
                <td><?php echo $row['stok']; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <a href="logout.php">Logout</a>
</body>
</html>
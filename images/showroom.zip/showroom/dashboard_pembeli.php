<?php
session_start();

$servername = 'localhost';
$dbname = 'db_showroom';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// Array deskripsi mobil, diisi secara manual
$carDescriptions = [
    'MOB01' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak</li>
                Jarak tempuh: 50,000 km</li>
                Kaki-kaki (shock breaker): Baru, part original</li>
                Kelistrikan: Aman</li>
                Indikator fitur speedometer: Aman</li>
                Sistem kendaraan: Injeksi</li>
                Jenis transmisi: Manual</li>
                Jenis mesin: 4-Tak, ICE</li>",

    'MOB02' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 75,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE ",

    'MOB03' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 40,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Manual
                Jenis mesin: 4-Tak, ICE",

    'MOB04' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 40,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Manual
                Jenis mesin: 4-Tak, ICE",

    'MOB05' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 10,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: Hybrid",

    'MOB06' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 90,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB07' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 5,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: Hybrid",

    'MOB08' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 10,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE",

    'MOB09' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 30,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Manual
                Jenis mesin: 4-Tak, ICE ",

    'MOB10' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 50,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: DCT
                Jenis mesin: 4-Tak, ICE",

    'MOB11' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 20,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Manual
                Jenis mesin: 4-Tak, ICE",

    'MOB12' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 85,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB13' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 85,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB14' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 15,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE",

    'MOB15' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 75,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB16' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 25,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE",


    'MOB17' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 20,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB18' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 5,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB19' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 1,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE",

    'MOB20' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 500 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB21' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 90,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Manual
                Jenis mesin: 4-Tak, ICE",

    'MOB22' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 500 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE",

    'MOB23' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 2,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB24' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 3,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE",

    'MOB25' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 4,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB26' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 5,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE",
    'MOB27' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 1,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB28' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 10,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE",

    'MOB29' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 2,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE",
    'MOB30' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 12,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE
                Merek: Suzuki
                Model: Swift",

    'MOB31' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 30,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Manual
                Jenis mesin: 4-Tak, ICE
                Merek: Suzuki
                Model: SX4",

    'MOB32' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 50,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE
                Merek: Suzuki
                Model: Ignis",

    'MOB33' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 18,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE
                Merek: Suzuki
                Model: S-Presso",

    'MOB34' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 25,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Manual
                Jenis mesin: 4-Tak, ICE
                Merek: Suzuki
                Model: Celerio",

    'MOB35' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 45,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE
                Merek: Suzuki
                Model: Jimny",
    'MOB36' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 30,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Manual
                Jenis mesin: 4-Tak, ICE
                Merek: Ford
                Model: Mustang",

    'MOB37' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 20,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE
                Merek: Ford
                Model: Ranger",

    'MOB38' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 10,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: CVT
                Jenis mesin: 4-Tak, ICE
                Merek: Ford
                Model: Everest",

    'MOB39' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 60,000 km
                Kaki-kaki (shock breaker): Part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE
                Merek: Ford
                Model: Explorer",

    'MOB40' => "Kesehatan mesin: Sehat
                Pernah bongkar mesin: Tidak
                Jarak tempuh: 5,000 km
                Kaki-kaki (shock breaker): Baru, part original
                Kelistrikan: Aman
                Indikator fitur speedometer: Aman
                Sistem kendaraan: Injeksi
                Jenis transmisi: Otomatis konvensional
                Jenis mesin: 4-Tak, ICE
                Merek: Ford
                Model: Bronco",
];

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

// Proses logout
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}

// Fungsi untuk membersihkan nilai harga dari format string
function cleanPrice($price) {
    // Menghapus "Rp", tanda titik, atau spasi yang mungkin ada di nilai harga
    $cleanedPrice = preg_replace('/[^0-9]/', '', $price);
    return (float) $cleanedPrice; // Pastikan hasilnya berupa float/number
}

function perceptron($car_price, $budget, $car_brand, $preferred_brand, $car_model, $preferred_model) {
    $price_score = ($budget !== null) ? abs($budget - $car_price) : PHP_INT_MAX;

    $brand_score = ($preferred_brand && strtolower($car_brand) != strtolower($preferred_brand)) ? PHP_INT_MAX : 0;
    $model_score = ($preferred_model && strtolower($car_model) != strtolower($preferred_model)) ? PHP_INT_MAX : 0;

    $total_score = $price_score + $brand_score + $model_score;

    return $total_score;
}

// Ambil semua mobil dari database
try {
    $stmt = $pdo->query("SELECT * FROM mobil");
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cars = [];
    echo "Error: " . $e->getMessage();
}

$displayedCars = [];

// Ambil input pengguna
$budget = isset($_GET['budget']) && $_GET['budget'] !== '' ? (float)$_GET['budget'] : null;
$preferred_brand = isset($_GET['merk']) && $_GET['merk'] !== '' ? $_GET['merk'] : null;
$preferred_model = isset($_GET['model']) && $_GET['model'] !== '' ? $_GET['model'] : null;

// Fungsi untuk membuat ID penjualan acak
function generateRandomId($length = 10) {
    return substr(bin2hex(random_bytes($length)), 0, $length);
}

// Proses pembelian produk
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['buy_product'])) {
    $id_mobil = $_POST['id_mobil'];
    $id_pembeli = $_SESSION['id_pembeli']; // Ambil ID pembeli dari sesi
    $id_pegawai = 'PGW01'; // ID pegawai bisa diambil dari sesi atau set secara default
    $jumlah = 1; // Misalkan 1 unit yang dibeli

    // Kurangi stok mobil sebanyak 1
    try {
        $stmt = $pdo->prepare("SELECT stok, harga FROM mobil WHERE id_mobil = ?");
        $stmt->execute([$id_mobil]);
        $car = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($car && $car['stok'] > 0) {
            $newStock = $car['stok'] - 1;
            $stmt = $pdo->prepare("UPDATE mobil SET stok = ? WHERE id_mobil = ?");
            $stmt->execute([$newStock, $id_mobil]);

            // Hitung total harga
            $total_harga = $car['harga'] * $jumlah;

            // Buat ID penjualan acak
            $id_penjualan = generateRandomId();

            // Masukkan data ke tabel penjualan
            $stmt = $pdo->prepare("INSERT INTO penjualan (id_penjualan, id_mobil, id_pembeli, id_pegawai, tanggal_penjualan, jumlah, total_harga) VALUES (?, ?, ?, ?, NOW(), ?, ?)");
            $stmt->execute([$id_penjualan, $id_mobil, $id_pembeli, $id_pegawai, $jumlah, $total_harga]);

            // Set session untuk pembelian berhasil agar pop up hanya muncul sekali
            $_SESSION['success'] = "Pembelian berhasil!";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            $_SESSION['alert'] = "Maaf, mobil tidak tersedia atau stok habis.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

$filteredCars = [];

// Jika ada parameter pencarian, filter mobil berdasarkan input pengguna
if (!is_null($budget) || !is_null($preferred_brand) || !is_null($preferred_model)) {
    foreach ($cars as &$car) {
        $car['harga'] = preg_replace('/[^0-9]/', '', $car['harga']);
        $car['harga'] = (float)$car['harga'];

        // Hitung perceptron score
        $car['perceptron_score'] = perceptron(
            $car['harga'],
            $budget,
            $car['merek'],
            $preferred_brand,
            $car['model'],
            $preferred_model
        );

        if (
            ($budget === null || abs($budget - $car['harga']) <= $budget * 0.2) &&
            ($preferred_brand === null || strtolower($car['merek']) == strtolower($preferred_brand)) &&
            ($preferred_model === null || strtolower($car['model']) == strtolower($preferred_model))
        ) {
            $filteredCars[] = $car;
        }
    }

    // Jika tidak ada mobil yang sesuai, tambahkan parameter 'alert' ke session
    if (empty($filteredCars)) {
        $_SESSION['alert'] = "Maaf, mobil yang anda cari tidak tersedia. Berikut adalah mobil yang tersedia di showroom.";
        $filteredCars = $cars; // Tetap tampilkan semua mobil yang ada
    }
} else {
    foreach ($cars as &$car) {
        // Set default perceptron score agar tidak muncul error saat pengurutan
        $car['perceptron_score'] = PHP_INT_MAX;
    }
    $filteredCars = $cars;
}

// Tampilkan alert jika terdapat session 'alert' dan bukan hasil dari tombol kembali
if (isset($_SESSION['alert'])) {
    echo "<script>alert('" . $_SESSION['alert'] . "');</script>";
    unset($_SESSION['alert']); // Hapus session setelah menampilkan alert
}

// Tampilkan pesan pembelian berhasil jika terdapat session 'success'
if (isset($_SESSION['success'])) {
    echo "<script>alert('" . $_SESSION['success'] . "');</script>";
    unset($_SESSION['success']); // Hapus session setelah menampilkan pesan
}

// Urutkan mobil berdasarkan skor perceptron (jika ada)
usort($filteredCars, function ($a, $b) {
    return ($a['perceptron_score'] ?? PHP_INT_MAX) <=> ($b['perceptron_score'] ?? PHP_INT_MAX);
});
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jaya Abadi</title>
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <script src="js/scripts.js" defer></script>
    <script>
        function showDetails(button) {
            var carItem = button.closest(".car-item");
            var carId = carItem.dataset.carId;
            var carTitle = carItem.querySelector(".car-title").innerText;
            var carPrice = carItem.querySelector(".harga").innerText;
            var carDescription = carItem.querySelector(".deskripsi").innerText;

            var popup = document.getElementById('carDetailPopup');
            document.getElementById('carTitle').innerText = carTitle;
            document.getElementById('carPrice').innerText = carPrice;
            document.getElementById('carDescription').innerText = carDescription;

            // Set posisi popup berdasarkan posisi elemen
            var rect = carItem.getBoundingClientRect();
            popup.style.top = rect.bottom + window.scrollY + 'px';
            popup.style.left = (rect.left + rect.width / 2) - (popup.offsetWidth / 2) + 'px';
            popup.style.display = 'block';
        }

        function hideDetails() {
            document.getElementById('carDetailPopup').style.display = 'none';
        }
    </script>
</head>
<body>
    <div class="wrapper">
        <header>
        <h1>Showroom Jaya Abadi</h1>
        <p class="subtitle">Temukan Mobil Impian Anda!<br><span class="since">Berdiri sejak tahun 1980</span></p>
    </header>


    <div class="container">
            <!-- Tombol Kembali dan Logout di bagian atas -->
            <div id="header-buttons">
                <!-- Tombol Kembali -->
                <button id="back-btn" onclick="window.history.back();">Kembali</button>

                <!-- Tombol Logout -->
                <form action="" method="post" class="logout">
                    <input type="submit" name="logout" value="Logout" class="logout-btn">
                </form>
            </div>

            <!-- Form Pencarian -->
            <div id="search-section">
                <form method="get" action="" id="search-form">
                    <input type="number" id="budget" name="budget" placeholder="Masukkan Budget Anda (Contoh: 150000000)">
                    <input type="text" id="merk" name="merk" placeholder="Pilih Merek (Contoh: Toyota)">
                    <input type="text" id="model" name="model" placeholder="Pilih Model (Contoh: Jazz)">
                    <input type="submit" value="Cari Mobil" id="search-btn">
                </form>
            </div>

        <h2>Daftar Mobil</h2>
        <div class="cars">
            <?php if (!empty($filteredCars)): ?>
                <?php foreach ($filteredCars as $car): ?>
                    <?php
                    // Cek apakah mobil sudah pernah ditampilkan
                    if (in_array($car['id_mobil'], $displayedCars)) {
                        continue; // Jika sudah, lewati mobil ini
                    }

                    $displayedCars[] = $car['id_mobil'];

                    // Buat nama gambar berdasarkan merek dan model mobil, sesuaikan dengan format gambar yang ada
                    $imageName = '';

                    switch (strtolower($car['merek'])) {
                        case 'nissan':
                            if (strtolower($car['model']) == 'altima') {
                                $imageName = 'nissan altima.jpg';
                            } else {
                                $imageName = strtolower(str_replace(' ', '', $car['merek'])) . '' . strtolower(str_replace(' ', '_', $car['model'])) . '.jpg';
                            }
                            break;
                    
                        case 'bmw':
                            if (strtolower($car['model']) == 'sedan') {
                                $imageName = 'bmw sedan.jpg';
                            } else {
                                $imageName = strtolower(str_replace(' ', '', $car['merek'])) . '' . strtolower(str_replace(' ', '_', $car['model'])) . '.jpg';
                            }
                            break;
                    
                        case 'suzuki':
                            if (strtolower($car['model']) == 'baleno') {
                                $imageName = 'suzuki baleno.jpg';
                            } else if (strtolower($car['model']) == 'ertiga') {
                                $imageName = 'ertiga.jpg';
                            } else if (strtolower($car['model']) == 'vitara') {
                                $imageName = 'suzuki vitara.jpg';
                            } else if (strtolower($car['model']) == 'swift') {
                                $imageName = 'swift.jpg';
                            } else if (strtolower($car['model']) == 'sx4') {
                                $imageName = 'sx4.jpg';
                            } else if (strtolower($car['model']) == 'ignis') {
                                $imageName = 'ignis.jpg';
                            } else if (strtolower($car['model']) == 's-presso') {
                                $imageName = 's-presso.jpg';
                            } else if (strtolower($car['model']) == 'celerio') {
                                $imageName = 'celerio.jpg';
                            } else if (strtolower($car['model']) == 'jimny') {
                                $imageName = 'jimny.jpg';
                            } else {
                                $imageName = strtolower(str_replace(' ', '', $car['merek'])) . '' . strtolower(str_replace(' ', '_', $car['model'])) . '.jpg';
                            }
                            break;
                    
                        case 'toyota':
                            if (strtolower($car['model']) == 'corolla') {
                                $imageName = 'corolla.jpg';
                            } else if (strtolower($car['model']) == 'avanza') {
                                $imageName = 'avanza.jpg';
                            } else if (strtolower($car['model']) == 'hilux') {
                                $imageName = 'toyota hilux.jpg';
                            } else if (strtolower($car['model']) == 'camry') {
                                $imageName = 'toyota camry.jpg';
                            } else if (strtolower($car['model']) == 'voxy') {
                                $imageName = 'toyota voxy.jpg';
                            } else if (strtolower($car['model']) == 'rush') {
                                $imageName = 'rush.jpg';
                            } else if (strtolower($car['model']) == 'fortuner') {
                                $imageName = 'fortuner.jpg';
                            } else if (strtolower($car['model']) == 'yaris') {
                                $imageName = 'yaris.jpg';
                            } else {
                                $imageName = strtolower(str_replace(' ', '', $car['merek'])) . '' . strtolower(str_replace(' ', '_', $car['model'])) . '.jpg';
                            }
                            break;
                    
                        case 'honda':
                            if (strtolower($car['model']) == 'jazz') {
                                $imageName = 'jazz.jpg';
                            } else if (strtolower($car['model']) == 'brio') {
                                $imageName = 'brio.jpg';
                            } else if (strtolower($car['model']) == 'civic') {
                                $imageName = 'civic.jpg';
                            } else if (strtolower($car['model']) == 'brv') {
                                $imageName = 'brv.jpg';
                            } else if (strtolower($car['model']) == 'accord') {
                                $imageName = 'accord.jpg';
                            } else if (strtolower($car['model']) == 'cr-v') {
                                $imageName = 'cr-v.jpg';
                            } else if (strtolower($car['model']) == 'hr-v') {
                                $imageName = 'hr-v.jpg';
                            } else if (strtolower($car['model']) == 'mobilio') {
                                $imageName = 'mobilio.jpg';
                            } else {
                                $imageName = strtolower(str_replace(' ', '', $car['merek'])) . '' . strtolower(str_replace(' ', '_', $car['model'])) . '.jpg';
                            }
                            break;
                    
                        case 'mitsubishi':
                            if (strtolower($car['model']) == 'fortuner') {
                                $imageName = 'fortuner.jpg';
                            } else if (strtolower($car['model']) == 'xpander') {
                                $imageName = 'mitsubishi xpander.jpg';
                            } else if (strtolower($car['model']) == 'pajero') {
                                $imageName = 'pajero.jpg';
                            } else if (strtolower($car['model']) == 'outlander') {
                                $imageName = 'outlander.jpg';
                            } else {
                                $imageName = strtolower(str_replace(' ', '', $car['merek'])) . '' . strtolower(str_replace(' ', '_', $car['model'])) . '.jpg';
                            }
                            break;
                    
                        case 'ford':
                            if (strtolower($car['model']) == 'fusion') {
                                $imageName = 'fusion.jpg';
                            } else if (strtolower($car['model']) == 'ecosport') {
                                $imageName = 'ford ecosport.jpg';
                            } else if (strtolower($car['model']) == 'fiesta') {
                                $imageName = 'fiesta.jpg';
                            } else if (strtolower($car['model']) == 'mustang') {
                                $imageName = 'mustang.jpg';
                            } else if (strtolower($car['model']) == 'ranger') {
                                $imageName = 'ranger.jpg';
                            } else if (strtolower($car['model']) == 'everest') {
                                $imageName = 'everest.jpg';
                            } else if (strtolower($car['model']) == 'explorer') {
                                $imageName = 'explorer.jpg';
                            }else {
                                $imageName = strtolower(str_replace(' ', '', $car['merek'])) . '' . strtolower(str_replace(' ', '_', $car['model'])) . '.jpg';
                            }
                            break;
                    
                        case 'hyundai':
                            if (strtolower($car['model']) == 'sonata') {
                                $imageName = 'sonata.jpg';
                            } else if (strtolower($car['model']) == 'creta') {
                                $imageName = 'creta.jpg';
                            } else if (strtolower($car['model']) == 'tucson') {
                                $imageName = 'tucson.jpg';
                            } else {
                                $imageName = strtolower(str_replace(' ', '', $car['merek'])) . '' . strtolower(str_replace(' ', '_', $car['model'])) . '.jpg';
                            }
                            break;
                    
                        default:
                            // Jika tidak ada gambar spesifik untuk merek, gunakan format umum berdasarkan merek dan model
                            $imageName = strtolower(str_replace(' ', '', $car['merek'])) . '' . strtolower(str_replace(' ', '_', $car['model'])) . '.jpg';
                            break;
                    }

                    // Path gambar
                    $imagePath = "assets/" . $imageName;

                    // Jika gambar tidak ditemukan, gunakan gambar default
                    if (!file_exists($imagePath)) {
                        $imagePath = "assets/default.jpg";
                    }

                    // Ambil deskripsi dari array berdasarkan id_mobil
                    $carDescription = isset($carDescriptions[$car['id_mobil']]) ? $carDescriptions[$car['id_mobil']] : "Deskripsi belum tersedia.";
                    ?>

                                <div class="car-item" data-car-id="<?php echo $car['id_mobil']; ?>">
                                <img src="<?php echo $imagePath; ?>" alt="<?php echo $car['merek'] . ' ' . $car['model']; ?>">
                                <div class="car-info">
                                    <p class="car-title"><strong><?php echo "{$car['merek']} {$car['model']} ({$car['tahun']})"; ?></strong></p>
                                    <p class="harga">Harga: Rp <?php echo number_format($car['harga'], 0, ',', '.'); ?></p>
                                    <p class="deskripsi" style="display:none;"><?php echo $carDescription; ?></p>
                                </div>
                                <a href="#" class="detail-link" onmouseover="showDetails(this)" onmouseout="hideDetails()">Detail</a>
                                <form action="" method="post">
                                    <input type="hidden" name="id_mobil" value="<?php echo $car['id_mobil']; ?>">
                                    <input type="submit" name="buy_product" value="Beli Mobil" class="buy-btn">
                                </form>
                            </div>

                <?php endforeach; ?>
            <?php else: ?>
                <p style="text-align: center;">Tidak ada mobil tersedia saat ini.</p>
            <?php endif; ?>
        </div>
    </div>

    <div id="carDetailPopup" class="popup" style="display:none;">
    <h3 id="carTitle">Detail Mobil</h3>
    <p id="carPrice">Harga Mobil</p>
    <p id="carDescription">Deskripsi mobil yang diinginkan.</p>
</div>

    <div class="footer">
        <p>&copy; 2024 Showroom Jaya Abadi. Semua hak dilindungi.</p>
    </div>
</body>
</html>
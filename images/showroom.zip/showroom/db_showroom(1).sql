-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2024 at 01:54 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_showroom`
--

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE `mobil` (
  `id_mobil` varchar(11) NOT NULL,
  `merek` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `tahun` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `stok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`id_mobil`, `merek`, `model`, `tahun`, `harga`, `stok`) VALUES
('MOB01', 'Toyota', 'Avanza', 2018, 80000000, 0),
('MOB02', 'Honda', 'Jazz', 2016, 90000000, 0),
('MOB03', 'Suzuki', 'Ertiga', 2019, 73000000, 0),
('MOB04', 'Mitsubishi', 'Fortuner', 2016, 270000000, 1),
('MOB05', 'Toyota', 'Hilux', 2022, 175000000, 1),
('MOB06', 'Hyundai', 'Sonata', 2023, 150000000, 2),
('MOB07', 'Ford', 'Fusion', 2015, 65000000, 1),
('MOB08', 'Toyota', 'Corolla', 2023, 100000000, 1),
('MOB09', 'Nissan', 'Altima', 2023, 300000000, 1),
('MOB10', 'Honda', 'Brio', 2020, 110000000, 0),
('MOB11', 'BMW', 'Sedan', 2019, 220000000, 0),
('MOB12', 'Suzuki', 'Baleno', 2020, 112000000, 1),
('MOB13', 'Suzuki', 'Vitara', 2015, 85000000, 2),
('MOB14', 'Toyota', 'Voxy', 2021, 410000000, 2),
('MOB15', 'Ford', 'Ecosport', 2016, 215000000, 2),
('MOB16', 'Mitsubishi', 'Outlander', 2020, 413000000, 2),
('MOB17', 'Toyota', 'Camry', 2021, 230000000, 2),
('MOB18', 'Toyota', 'Rush', 2023, 278000000, 2),
('MOB19', 'Honda', 'BRV', 2024, 303000000, 1),
('MOB20', 'Mitsubishi', 'Pajero', 2024, 767000000, 0),
('MOB21', 'Ford', 'Fiesta', 2014, 89000000, 1),
('MOB22', 'Hyundai', 'Creta', 2024, 301000000, 2),
('MOB23', 'Honda', 'Accord', 2024, 500000000, 3),
('MOB24', 'Honda', 'CR-V', 2024, 600000000, 5),
('MOB25', 'Honda', 'HR-V', 2024, 400000000, 4),
('MOB26', 'Honda', 'Mobilio', 2024, 350000000, 2),
('MOB27', 'Hyundai', 'Tucson', 2023, 750000000, 2),
('MOB28', 'Toyota', 'Fortuner', 2020, 550000000, 2),
('MOB29', 'Toyota', 'Yaris', 2021, 310000000, 5),
('MOB30', 'Suzuki', 'Swift', 2020, 180000000, 2),
('MOB31', 'Suzuki', 'SX4', 2019, 200000000, 1),
('MOB32', 'Suzuki', 'Ignis', 2021, 150000000, 3),
('MOB33', 'Suzuki', 'S-Presso', 2022, 140000000, 2),
('MOB34', 'Suzuki', 'Celerio', 2018, 120000000, 4),
('MOB35', 'Suzuki', 'Jimny', 2023, 450000000, 1),
('MOB36', 'Ford', 'Mustang', 2022, 800000000, 1),
('MOB37', 'Ford', 'Ranger', 2021, 500000000, 3),
('MOB38', 'Ford', 'Everest', 2023, 700000000, 2),
('MOB39', 'Ford', 'Explorer', 2020, 600000000, 1),
('MOB40', 'Ford', 'Bronco', 2024, 900000000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `id_pegawai` varchar(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nama`, `email`, `password`) VALUES
('PGW01', 'Ciyat', 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `pembeli`
--

CREATE TABLE `pembeli` (
  `id_pembeli` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `telepon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembeli`
--

INSERT INTO `pembeli` (`id_pembeli`, `email`, `password`, `nama`, `alamat`, `telepon`) VALUES
('205312', 'panda@gmail.com', '$2y$10$5RSil4qK3OQU3MFWeQa7HOpYAwRsLFrxVUqDDUn2bBvam.gLcgFQy', 'Panda', 'JL. Turi', '08976432382'),
('263072', 'madan@gmail.com', '$2y$10$JxMIox5uSu1SKgktQGWnUO/2Ls3vQHO/qDWwquVFghpXXlvjgQFky', 'Madan', 'JL. Sakan', '08976432384'),
('491604', 'cantik@gmail.com', '$2y$10$8yretOFhwjnNyCie9RCZKevBFgO.FEh21ig630IHG5bEtLVWEw9I2', 'Cantik', 'JL. Jati Gang Mahoni No. 10', '08976438777'),
('846675', 'oliv@gmail.com', '$2y$10$K79hTjc7m5ePdvJxobcLwuzX.sOiVWjOAqoTavmJ2v.ihe9AAEKEi', 'Oliv', 'JL. Jati ', '08937477489');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` varchar(11) NOT NULL,
  `id_mobil` varchar(11) NOT NULL,
  `id_pembeli` varchar(11) NOT NULL,
  `id_pegawai` varchar(11) NOT NULL,
  `tanggal_penjualan` date NOT NULL,
  `jumlah` int(50) NOT NULL,
  `total_harga` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `id_mobil`, `id_pembeli`, `id_pegawai`, `tanggal_penjualan`, `jumlah`, `total_harga`) VALUES
('1BScwQ8NlA', 'MOB01', '263072', 'PGW01', '2024-05-13', 1, 80000000),
('20n2jzT04k', 'MOB07', '491604', 'PGW01', '2024-05-13', 1, 65000000),
('b622XV7MWr', 'MOB01', '263072', 'PGW01', '2024-05-13', 1, 80000000),
('BkBWrKNRbU', 'MOB03', '263072', 'PGW01', '2024-05-13', 1, 72000000),
('HubZQAd4SI', 'MOB13', '846675', 'PGW01', '2024-10-16', 1, 85000000),
('oF6f7ZuJCX', 'MOB12', '263072', 'PGW01', '2024-05-17', 1, 112000000),
('UHm5dq18iT', 'MOB10', '846675', 'PGW01', '2024-10-15', 1, 110000000),
('wbMA3jduuU', 'MOB04', '263072', 'PGW01', '2024-05-17', 1, 270000000),
('wjTSHVYCKw', 'MOB10', '263072', 'PGW01', '2024-05-13', 1, 110000000),
('y612CE76en', 'MOB13', '263072', 'PGW01', '2024-05-13', 1, 85000000),
('ZcWOZEJwrM', 'MOB02', '263072', 'PGW01', '2024-05-13', 1, 90000000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`id_mobil`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indexes for table `pembeli`
--
ALTER TABLE `pembeli`
  ADD PRIMARY KEY (`id_pembeli`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`),
  ADD KEY `id_mobil` (`id_mobil`),
  ADD KEY `id_pembeli` (`id_pembeli`),
  ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `penjualan_ibfk_1` FOREIGN KEY (`id_mobil`) REFERENCES `mobil` (`id_mobil`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `penjualan_ibfk_2` FOREIGN KEY (`id_pegawai`) REFERENCES `pegawai` (`id_pegawai`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `penjualan_ibfk_3` FOREIGN KEY (`id_pembeli`) REFERENCES `pembeli` (`id_pembeli`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
